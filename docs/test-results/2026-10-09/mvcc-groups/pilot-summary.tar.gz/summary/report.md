# MVCC benchmark results

Validated **100 processes / 280 phase rows**.

Each table reports the median of independent fresh-process repetitions. summary.csv includes quartiles, min/max and sample counts. Quartiles are descriptive, not confidence intervals. Compare candidates within a cohort; different key populations are kept separate.

Current groups are reported separately: OLTP captures the latest completed batch at each request start; history holds a fixed completed-round snapshot. Latest concurrent results are verified against an independent oracle using the exact captured timestamps after timing. Their visible values/hit counts/checksums can differ with scheduling; only deterministic request/write/dataset counts are compared across adapters. Fixed-view results retain cross-adapter content equality. Actual visibility counts and oracle checksums remain in raw CSV. Legacy mvcc-v1 archives retain their original both-view/fixed-snapshot protocol.

Writes are batch submissions, not atomic transactions. GetAt materializes values; scans hash visible live rows; flush hashes every retained version and tombstone. Adapter/encoding/FFI costs are included. No WAL, SST encoding or disk I/O is measured. SWMR uses one writer and N-1 readers with the selected read view; single-worker mixed timing is a different interleaving. Reader service throughput uses the complete group wall interval, including the tail after writing.

The shared host has CPU/NUMA binding but no frequency lock or reserved CPUs. Stage-1 scans have 1024 calls and about 16 latency samples; their p99 is not a stable tail estimate. Aggregate SWMR latency is intentionally absent. Reader service latency mixes Get and Scan. Current default mixed workloads use scan-percent=0 to keep their reader latency point-only; dedicated scans remain in stage 1. RSS deltas include allocator/runtime retention and are measured after input preparation. CSE backend accounting is not interchangeable with RSS. Phase elapsed time includes PMU start/stop and sampling setup. For a one-request Freeze phase this overhead dominates; the separately sampled call excludes PMU control but still includes clock/call instrumentation. Neither is a stable native-only Freeze latency estimate.

## pilot: oltp / oltp_uniform

User keys: 1,000; operation budget: 4,000; repetitions: 1. Profile: `{"batch_size": 32, "delete_percent": 10, "distribution": "uniform", "key_layout": "random", "key_size": 16, "miss_percent": 10, "prefix_bytes": 0, "prefix_groups": 1, "read_percent": 80, "read_view": "latest", "scan_length": 100, "scan_ops": 1024, "scan_percent": 0, "snapshot_lag": 0, "value_size": 32, "versions": 2}`.

### Single-thread operations

| Index | Load Mversions/s | Latest Get Mreq/s | Latest scan Mrows/s | RSS MiB after load | Bytes/version |
| --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 2.948 | 2.413 | 6.786 | 0.316 | 165.888 |
| btreeolc | 1.546 | 2.158 | 1.819 | 0.574 | 301.056 |
| unodb_art | 1.642 | 1.425 | 0.699 | 0.777 | 407.552 |
| wormhole | 2.162 | 1.849 | 2.075 | 10.887 | 5707.776 |
| cse_crossbeam | 1.743 | 2.968 | 6.770 | 0.754 | 395.264 |

### Latest published batch: mixed / SWMR

| Index | 1 workers Mreq/s | 4 workers Mreq/s | 8 workers Mreq/s | 4 workers: readers Mreq/s | 8 workers: readers Mreq/s | 4 workers: writer Mversions/s | 8 workers: writer Mversions/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 1.954 | 3.929 | 5.181 | 3.899 | 5.140 | 2.117 | 1.823 |
| btreeolc | 1.478 | 3.257 | 3.533 | 3.232 | 3.506 | 0.908 | 1.009 |
| unodb_art | 1.230 | 3.005 | 4.257 | 2.982 | 4.224 | 1.486 | 1.388 |
| wormhole | 1.336 | 2.868 | 3.669 | 2.846 | 3.641 | 1.470 | 1.266 |
| cse_crossbeam | 1.959 | 4.180 | 4.008 | 4.148 | 3.977 | 1.197 | 1.264 |

### Latest visibility evidence

| Index | Workers | Min observed snapshot | Max observed snapshot | Reads after newer publication | Point hits on new versions |
| --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 1 | 2000.000 | 2800.000 | 3142.000 | 868.000 |
| rocksdb_inlineskiplist | 4 | 2000.000 | 2800.000 | 3166.000 | 1365.000 |
| rocksdb_inlineskiplist | 8 | 2000.000 | 2736.000 | 2900.000 | 633.000 |
| btreeolc | 1 | 2000.000 | 2800.000 | 3142.000 | 868.000 |
| btreeolc | 4 | 2000.000 | 2800.000 | 3115.000 | 919.000 |
| btreeolc | 8 | 2000.000 | 2320.000 | 3007.000 | 416.000 |
| unodb_art | 1 | 2000.000 | 2800.000 | 3142.000 | 868.000 |
| unodb_art | 4 | 2000.000 | 2800.000 | 3153.000 | 1284.000 |
| unodb_art | 8 | 2000.000 | 2608.000 | 3034.000 | 689.000 |
| wormhole | 1 | 2000.000 | 2800.000 | 3142.000 | 868.000 |
| wormhole | 4 | 2000.000 | 2800.000 | 3182.000 | 1448.000 |
| wormhole | 8 | 2000.000 | 2800.000 | 3084.000 | 775.000 |
| cse_crossbeam | 1 | 2000.000 | 2800.000 | 3142.000 | 868.000 |
| cse_crossbeam | 4 | 2000.000 | 2768.000 | 3092.000 | 869.000 |
| cse_crossbeam | 8 | 2000.000 | 2352.000 | 2919.000 | 425.000 |

### Lifecycle

| Index | Load s | Freeze phase µs | Freeze sampled call µs | Flush Mversions/s | Destroy s |
| --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 0.001 | 24.733 | 0.333 | 10.876 | 0.000 |
| btreeolc | 0.001 | 24.163 | 0.269 | 10.135 | 0.000 |
| unodb_art | 0.001 | 23.246 | 0.265 | 3.136 | 0.000 |
| wormhole | 0.001 | 24.489 | 0.133 | 7.233 | 0.001 |
| cse_crossbeam | 0.001 | 24.586 | 0.382 | 7.039 | 0.000 |

## pilot: oltp / oltp_zipf

User keys: 1,000; operation budget: 4,000; repetitions: 1. Profile: `{"batch_size": 32, "delete_percent": 10, "distribution": "zipf", "key_layout": "random", "key_size": 16, "miss_percent": 10, "prefix_bytes": 0, "prefix_groups": 1, "read_percent": 80, "read_view": "latest", "scan_length": 100, "scan_ops": 1024, "scan_percent": 0, "snapshot_lag": 0, "value_size": 32, "versions": 2}`.

### Single-thread operations

| Index | Load Mversions/s | Latest Get Mreq/s | Latest scan Mrows/s | RSS MiB after load | Bytes/version |
| --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 2.907 | 2.566 | 6.839 | 0.512 | 268.288 |
| btreeolc | 1.605 | 2.378 | 1.768 | 0.652 | 342.016 |
| unodb_art | 1.149 | 1.438 | 0.678 | 0.914 | 479.232 |
| wormhole | 2.166 | 1.951 | 2.394 | 10.965 | 5748.736 |
| cse_crossbeam | 1.709 | 3.437 | 6.753 | 0.887 | 464.896 |

### Latest published batch: mixed / SWMR

| Index | 1 workers Mreq/s | 4 workers Mreq/s | 8 workers Mreq/s | 4 workers: readers Mreq/s | 8 workers: readers Mreq/s | 4 workers: writer Mversions/s | 8 workers: writer Mversions/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 2.027 | 4.353 | 5.129 | 4.319 | 5.089 | 2.118 | 1.948 |
| btreeolc | 1.590 | 2.652 | 3.505 | 2.631 | 3.477 | 0.993 | 1.051 |
| unodb_art | 1.240 | 3.077 | 4.392 | 3.053 | 4.358 | 1.517 | 1.406 |
| wormhole | 1.321 | 2.592 | 3.164 | 2.572 | 3.140 | 1.165 | 0.997 |
| cse_crossbeam | 2.136 | 4.289 | 4.057 | 4.256 | 4.025 | 1.241 | 1.296 |

### Latest visibility evidence

| Index | Workers | Min observed snapshot | Max observed snapshot | Reads after newer publication | Point hits on new versions |
| --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 1 | 2000.000 | 2800.000 | 3142.000 | 1957.000 |
| rocksdb_inlineskiplist | 4 | 2000.000 | 2800.000 | 3187.000 | 2181.000 |
| rocksdb_inlineskiplist | 8 | 2000.000 | 2800.000 | 3042.000 | 1879.000 |
| btreeolc | 1 | 2000.000 | 2800.000 | 3142.000 | 1957.000 |
| btreeolc | 4 | 2000.000 | 2800.000 | 3180.000 | 2073.000 |
| btreeolc | 8 | 2000.000 | 2288.000 | 2741.000 | 1451.000 |
| unodb_art | 1 | 2000.000 | 2800.000 | 3142.000 | 1957.000 |
| unodb_art | 4 | 2000.000 | 2800.000 | 3195.000 | 2187.000 |
| unodb_art | 8 | 2000.000 | 2608.000 | 2998.000 | 1807.000 |
| wormhole | 1 | 2000.000 | 2800.000 | 3142.000 | 1957.000 |
| wormhole | 4 | 2000.000 | 2800.000 | 3179.000 | 2204.000 |
| wormhole | 8 | 2000.000 | 2640.000 | 3080.000 | 1921.000 |
| cse_crossbeam | 1 | 2000.000 | 2800.000 | 3142.000 | 1957.000 |
| cse_crossbeam | 4 | 2000.000 | 2800.000 | 3177.000 | 2053.000 |
| cse_crossbeam | 8 | 2000.000 | 2448.000 | 2834.000 | 1610.000 |

### Lifecycle

| Index | Load s | Freeze phase µs | Freeze sampled call µs | Flush Mversions/s | Destroy s |
| --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 0.001 | 23.455 | 0.253 | 11.073 | 0.000 |
| btreeolc | 0.001 | 24.324 | 0.274 | 9.480 | 0.000 |
| unodb_art | 0.001 | 27.424 | 0.275 | 2.554 | 0.000 |
| wormhole | 0.001 | 24.634 | 0.250 | 7.156 | 0.001 |
| cse_crossbeam | 0.001 | 27.267 | 0.770 | 5.592 | 0.000 |

## pilot: history / history_v16

User keys: 1,000; operation budget: 4,000; repetitions: 1. Profile: `{"batch_size": 32, "delete_percent": 10, "distribution": "uniform", "key_layout": "random", "key_size": 16, "miss_percent": 10, "prefix_bytes": 0, "prefix_groups": 1, "read_percent": 80, "read_view": "historical", "scan_length": 100, "scan_ops": 1024, "scan_percent": 0, "snapshot_lag": 15, "value_size": 32, "versions": 16}`.

### Single-thread operations

| Index | Load Mversions/s | Historical Get Mreq/s | Historical scan Mrows/s | RSS MiB after load | Bytes/version |
| --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 2.422 | 1.902 | 0.833 | 1.031 | 67.584 |
| btreeolc | 1.237 | 1.752 | 0.217 | 3.152 | 206.592 |
| unodb_art | 2.019 | 1.074 | 0.091 | 2.578 | 168.960 |
| wormhole | 2.308 | 1.291 | 0.312 | 11.859 | 777.216 |
| cse_crossbeam | 1.863 | 1.258 | 1.208 | 2.812 | 184.320 |

### Fixed historical snapshot: mixed / SWMR

| Index | 1 workers Mreq/s | 4 workers Mreq/s | 8 workers Mreq/s | 4 workers: readers Mreq/s | 8 workers: readers Mreq/s | 4 workers: writer Mversions/s | 8 workers: writer Mversions/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 1.515 | 3.182 | 4.274 | 3.157 | 4.241 | 1.304 | 1.358 |
| btreeolc | 1.144 | 2.709 | 2.708 | 2.688 | 2.687 | 0.731 | 0.780 |
| unodb_art | 1.136 | 2.559 | 3.735 | 2.539 | 3.706 | 1.220 | 1.129 |
| wormhole | 0.775 | 1.729 | 3.743 | 1.715 | 3.714 | 1.101 | 1.158 |
| cse_crossbeam | 1.014 | 2.040 | 3.917 | 2.024 | 3.887 | 1.297 | 1.216 |

### Lifecycle

| Index | Load s | Freeze phase µs | Freeze sampled call µs | Flush Mversions/s | Destroy s |
| --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 0.006 | 23.994 | 0.119 | 11.980 | 0.000 |
| btreeolc | 0.013 | 24.601 | 0.346 | 9.384 | 0.001 |
| unodb_art | 0.012 | 33.345 | 0.434 | 2.191 | 0.002 |
| wormhole | 0.007 | 25.155 | 0.259 | 7.603 | 0.002 |
| cse_crossbeam | 0.009 | 24.067 | 0.727 | 6.781 | 0.001 |

## pilot: history / history_v64

User keys: 1,000; operation budget: 4,000; repetitions: 1. Profile: `{"batch_size": 32, "delete_percent": 10, "distribution": "uniform", "key_layout": "random", "key_size": 16, "miss_percent": 10, "prefix_bytes": 0, "prefix_groups": 1, "read_percent": 80, "read_view": "historical", "scan_length": 100, "scan_ops": 1024, "scan_percent": 0, "snapshot_lag": 63, "value_size": 32, "versions": 64}`.

### Single-thread operations

| Index | Load Mversions/s | Historical Get Mreq/s | Historical scan Mrows/s | RSS MiB after load | Bytes/version |
| --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 1.908 | 1.629 | 0.177 | 4.898 | 80.256 |
| btreeolc | 1.035 | 1.413 | 0.035 | 12.895 | 211.264 |
| unodb_art | 1.980 | 1.298 | 0.020 | 9.281 | 152.064 |
| wormhole | 2.353 | 0.568 | 0.066 | 16.242 | 266.112 |
| cse_crossbeam | 1.862 | 0.313 | 0.225 | 10.090 | 165.312 |

### Fixed historical snapshot: mixed / SWMR

| Index | 1 workers Mreq/s | 4 workers Mreq/s | 8 workers Mreq/s | 4 workers: readers Mreq/s | 8 workers: readers Mreq/s | 4 workers: writer Mversions/s | 8 workers: writer Mversions/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 1.233 | 3.020 | 3.782 | 2.996 | 3.753 | 1.212 | 1.211 |
| btreeolc | 0.860 | 1.869 | 2.038 | 1.854 | 2.022 | 0.568 | 0.577 |
| unodb_art | 1.118 | 2.720 | 3.956 | 2.699 | 3.925 | 1.426 | 1.286 |
| wormhole | 0.290 | 1.164 | 1.426 | 1.155 | 1.415 | 0.300 | 0.382 |
| cse_crossbeam | 0.239 | 0.792 | 1.619 | 0.786 | 1.606 | 1.340 | 1.288 |

### Lifecycle

| Index | Load s | Freeze phase µs | Freeze sampled call µs | Flush Mversions/s | Destroy s |
| --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 0.034 | 25.254 | 0.165 | 10.164 | 0.000 |
| btreeolc | 0.063 | 25.275 | 0.300 | 5.717 | 0.002 |
| unodb_art | 0.032 | 24.473 | 0.412 | 2.729 | 0.010 |
| wormhole | 0.027 | 25.344 | 0.320 | 7.269 | 0.005 |
| cse_crossbeam | 0.036 | 33.043 | 0.957 | 4.254 | 0.014 |
