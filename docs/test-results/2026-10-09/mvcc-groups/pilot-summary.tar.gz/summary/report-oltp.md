# MVCC oltp benchmark

Validated group: **50 processes / 140 phase rows**.

Each table reports the median of independent fresh-process repetitions. summary.csv includes quartiles, min/max and sample counts. Quartiles are descriptive, not confidence intervals. Compare candidates within a cohort; different key populations are kept separate.

Current groups are reported separately: OLTP captures the latest completed batch at each request start; history holds a fixed completed-round snapshot. Latest concurrent results are verified against an independent oracle using the exact captured timestamps after timing. Their visible values/hit counts/checksums can differ with scheduling; only deterministic request/write/dataset counts are compared across adapters. Fixed-view results retain cross-adapter content equality. Actual visibility counts and oracle checksums remain in raw CSV. Legacy mvcc-v1 archives retain their original both-view/fixed-snapshot protocol.

Writes are batch submissions, not atomic transactions. GetAt materializes values; scans hash visible live rows; flush hashes every retained version and tombstone. Adapter/encoding/FFI costs are included. No WAL, SST encoding or disk I/O is measured. SWMR uses one writer and N-1 readers with the selected read view; single-worker mixed timing is a different interleaving. Reader service throughput uses the complete group wall interval, including the tail after writing.

The shared host has CPU/NUMA binding but no frequency lock or reserved CPUs. Stage-1 scans have 1024 calls and about 16 latency samples; their p99 is not a stable tail estimate. Aggregate SWMR latency is intentionally absent. Reader service latency mixes Get and Scan. Current default mixed workloads use scan-percent=0 to keep their reader latency point-only; dedicated scans remain in stage 1. RSS deltas include allocator/runtime retention and are measured after input preparation. CSE backend accounting is not interchangeable with RSS. Phase elapsed time includes PMU start/stop and sampling setup. For a one-request Freeze phase this overhead dominates; the separately sampled call excludes PMU control but still includes clock/call instrumentation. Neither is a stable native-only Freeze latency estimate.

## pilot: oltp / oltp_uniform

User keys: 1,000; operation budget: 4,000; repetitions: 1. Profile: `{"batch_size": 32, "delete_percent": 10, "distribution": "uniform", "key_layout": "random", "key_size": 16, "miss_percent": 10, "prefix_bytes": 0, "prefix_groups": 1, "read_percent": 80, "read_view": "latest", "scan_length": 100, "scan_ops": 1024, "scan_percent": 0, "snapshot_lag": 0, "value_size": 32, "versions": 2}`.

### Single-thread operations

| Index | Load Mversions/s | Latest Get Mreq/s | Latest scan Mrows/s | RSS MiB after load | Bytes/version |
| --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 2.948 | 2.413 | 6.786 | 0.316 | 165.888 |
| btreeolc | 1.546 | 2.158 | 1.819 | 0.574 | 301.056 |
| unodb_art | 1.642 | 1.425 | 0.699 | 0.777 | 407.552 |
| wormhole | 2.162 | 1.849 | 2.075 | 10.887 | 5707.776 |
| cse_crossbeam | 1.743 | 2.968 | 6.770 | 0.754 | 395.264 |

### Latest published batch: mixed / SWMR

| Index | 1 workers Mreq/s | 4 workers Mreq/s | 8 workers Mreq/s | 4 workers: readers Mreq/s | 8 workers: readers Mreq/s | 4 workers: writer Mversions/s | 8 workers: writer Mversions/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 1.954 | 3.929 | 5.181 | 3.899 | 5.140 | 2.117 | 1.823 |
| btreeolc | 1.478 | 3.257 | 3.533 | 3.232 | 3.506 | 0.908 | 1.009 |
| unodb_art | 1.230 | 3.005 | 4.257 | 2.982 | 4.224 | 1.486 | 1.388 |
| wormhole | 1.336 | 2.868 | 3.669 | 2.846 | 3.641 | 1.470 | 1.266 |
| cse_crossbeam | 1.959 | 4.180 | 4.008 | 4.148 | 3.977 | 1.197 | 1.264 |

### Latest visibility evidence

| Index | Workers | Min observed snapshot | Max observed snapshot | Reads after newer publication | Point hits on new versions |
| --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 1 | 2000.000 | 2800.000 | 3142.000 | 868.000 |
| rocksdb_inlineskiplist | 4 | 2000.000 | 2800.000 | 3166.000 | 1365.000 |
| rocksdb_inlineskiplist | 8 | 2000.000 | 2736.000 | 2900.000 | 633.000 |
| btreeolc | 1 | 2000.000 | 2800.000 | 3142.000 | 868.000 |
| btreeolc | 4 | 2000.000 | 2800.000 | 3115.000 | 919.000 |
| btreeolc | 8 | 2000.000 | 2320.000 | 3007.000 | 416.000 |
| unodb_art | 1 | 2000.000 | 2800.000 | 3142.000 | 868.000 |
| unodb_art | 4 | 2000.000 | 2800.000 | 3153.000 | 1284.000 |
| unodb_art | 8 | 2000.000 | 2608.000 | 3034.000 | 689.000 |
| wormhole | 1 | 2000.000 | 2800.000 | 3142.000 | 868.000 |
| wormhole | 4 | 2000.000 | 2800.000 | 3182.000 | 1448.000 |
| wormhole | 8 | 2000.000 | 2800.000 | 3084.000 | 775.000 |
| cse_crossbeam | 1 | 2000.000 | 2800.000 | 3142.000 | 868.000 |
| cse_crossbeam | 4 | 2000.000 | 2768.000 | 3092.000 | 869.000 |
| cse_crossbeam | 8 | 2000.000 | 2352.000 | 2919.000 | 425.000 |

### Lifecycle

| Index | Load s | Freeze phase µs | Freeze sampled call µs | Flush Mversions/s | Destroy s |
| --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 0.001 | 24.733 | 0.333 | 10.876 | 0.000 |
| btreeolc | 0.001 | 24.163 | 0.269 | 10.135 | 0.000 |
| unodb_art | 0.001 | 23.246 | 0.265 | 3.136 | 0.000 |
| wormhole | 0.001 | 24.489 | 0.133 | 7.233 | 0.001 |
| cse_crossbeam | 0.001 | 24.586 | 0.382 | 7.039 | 0.000 |

## pilot: oltp / oltp_zipf

User keys: 1,000; operation budget: 4,000; repetitions: 1. Profile: `{"batch_size": 32, "delete_percent": 10, "distribution": "zipf", "key_layout": "random", "key_size": 16, "miss_percent": 10, "prefix_bytes": 0, "prefix_groups": 1, "read_percent": 80, "read_view": "latest", "scan_length": 100, "scan_ops": 1024, "scan_percent": 0, "snapshot_lag": 0, "value_size": 32, "versions": 2}`.

### Single-thread operations

| Index | Load Mversions/s | Latest Get Mreq/s | Latest scan Mrows/s | RSS MiB after load | Bytes/version |
| --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 2.907 | 2.566 | 6.839 | 0.512 | 268.288 |
| btreeolc | 1.605 | 2.378 | 1.768 | 0.652 | 342.016 |
| unodb_art | 1.149 | 1.438 | 0.678 | 0.914 | 479.232 |
| wormhole | 2.166 | 1.951 | 2.394 | 10.965 | 5748.736 |
| cse_crossbeam | 1.709 | 3.437 | 6.753 | 0.887 | 464.896 |

### Latest published batch: mixed / SWMR

| Index | 1 workers Mreq/s | 4 workers Mreq/s | 8 workers Mreq/s | 4 workers: readers Mreq/s | 8 workers: readers Mreq/s | 4 workers: writer Mversions/s | 8 workers: writer Mversions/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 2.027 | 4.353 | 5.129 | 4.319 | 5.089 | 2.118 | 1.948 |
| btreeolc | 1.590 | 2.652 | 3.505 | 2.631 | 3.477 | 0.993 | 1.051 |
| unodb_art | 1.240 | 3.077 | 4.392 | 3.053 | 4.358 | 1.517 | 1.406 |
| wormhole | 1.321 | 2.592 | 3.164 | 2.572 | 3.140 | 1.165 | 0.997 |
| cse_crossbeam | 2.136 | 4.289 | 4.057 | 4.256 | 4.025 | 1.241 | 1.296 |

### Latest visibility evidence

| Index | Workers | Min observed snapshot | Max observed snapshot | Reads after newer publication | Point hits on new versions |
| --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 1 | 2000.000 | 2800.000 | 3142.000 | 1957.000 |
| rocksdb_inlineskiplist | 4 | 2000.000 | 2800.000 | 3187.000 | 2181.000 |
| rocksdb_inlineskiplist | 8 | 2000.000 | 2800.000 | 3042.000 | 1879.000 |
| btreeolc | 1 | 2000.000 | 2800.000 | 3142.000 | 1957.000 |
| btreeolc | 4 | 2000.000 | 2800.000 | 3180.000 | 2073.000 |
| btreeolc | 8 | 2000.000 | 2288.000 | 2741.000 | 1451.000 |
| unodb_art | 1 | 2000.000 | 2800.000 | 3142.000 | 1957.000 |
| unodb_art | 4 | 2000.000 | 2800.000 | 3195.000 | 2187.000 |
| unodb_art | 8 | 2000.000 | 2608.000 | 2998.000 | 1807.000 |
| wormhole | 1 | 2000.000 | 2800.000 | 3142.000 | 1957.000 |
| wormhole | 4 | 2000.000 | 2800.000 | 3179.000 | 2204.000 |
| wormhole | 8 | 2000.000 | 2640.000 | 3080.000 | 1921.000 |
| cse_crossbeam | 1 | 2000.000 | 2800.000 | 3142.000 | 1957.000 |
| cse_crossbeam | 4 | 2000.000 | 2800.000 | 3177.000 | 2053.000 |
| cse_crossbeam | 8 | 2000.000 | 2448.000 | 2834.000 | 1610.000 |

### Lifecycle

| Index | Load s | Freeze phase µs | Freeze sampled call µs | Flush Mversions/s | Destroy s |
| --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 0.001 | 23.455 | 0.253 | 11.073 | 0.000 |
| btreeolc | 0.001 | 24.324 | 0.274 | 9.480 | 0.000 |
| unodb_art | 0.001 | 27.424 | 0.275 | 2.554 | 0.000 |
| wormhole | 0.001 | 24.634 | 0.250 | 7.156 | 0.001 |
| cse_crossbeam | 0.001 | 27.267 | 0.770 | 5.592 | 0.000 |
