# MVCC history benchmark

Validated group: **50 processes / 140 phase rows**.

Each table reports the median of independent fresh-process repetitions. summary.csv includes quartiles, min/max and sample counts. Quartiles are descriptive, not confidence intervals. Compare candidates within a cohort; different key populations are kept separate.

Current groups are reported separately: OLTP captures the latest completed batch at each request start; history holds a fixed completed-round snapshot. Latest concurrent results are verified against an independent oracle using the exact captured timestamps after timing. Their visible values/hit counts/checksums can differ with scheduling; only deterministic request/write/dataset counts are compared across adapters. Fixed-view results retain cross-adapter content equality. Actual visibility counts and oracle checksums remain in raw CSV. Legacy mvcc-v1 archives retain their original both-view/fixed-snapshot protocol.

Writes are batch submissions, not atomic transactions. GetAt materializes values; scans hash visible live rows; flush hashes every retained version and tombstone. Adapter/encoding/FFI costs are included. No WAL, SST encoding or disk I/O is measured. SWMR uses one writer and N-1 readers with the selected read view; single-worker mixed timing is a different interleaving. Reader service throughput uses the complete group wall interval, including the tail after writing.

The shared host has CPU/NUMA binding but no frequency lock or reserved CPUs. Stage-1 scans have 1024 calls and about 16 latency samples; their p99 is not a stable tail estimate. Aggregate SWMR latency is intentionally absent. Reader service latency mixes Get and Scan. Current default mixed workloads use scan-percent=0 to keep their reader latency point-only; dedicated scans remain in stage 1. RSS deltas include allocator/runtime retention and are measured after input preparation. CSE backend accounting is not interchangeable with RSS. Phase elapsed time includes PMU start/stop and sampling setup. For a one-request Freeze phase this overhead dominates; the separately sampled call excludes PMU control but still includes clock/call instrumentation. Neither is a stable native-only Freeze latency estimate.

## pilot: history / history_v16

User keys: 1,000; operation budget: 4,000; repetitions: 1. Profile: `{"batch_size": 32, "delete_percent": 10, "distribution": "uniform", "key_layout": "random", "key_size": 16, "miss_percent": 10, "prefix_bytes": 0, "prefix_groups": 1, "read_percent": 80, "read_view": "historical", "scan_length": 100, "scan_ops": 1024, "scan_percent": 0, "snapshot_lag": 15, "value_size": 32, "versions": 16}`.

### Single-thread operations

| Index | Load Mversions/s | Historical Get Mreq/s | Historical scan Mrows/s | RSS MiB after load | Bytes/version |
| --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 2.422 | 1.902 | 0.833 | 1.031 | 67.584 |
| btreeolc | 1.237 | 1.752 | 0.217 | 3.152 | 206.592 |
| unodb_art | 2.019 | 1.074 | 0.091 | 2.578 | 168.960 |
| wormhole | 2.308 | 1.291 | 0.312 | 11.859 | 777.216 |
| cse_crossbeam | 1.863 | 1.258 | 1.208 | 2.812 | 184.320 |

### Fixed historical snapshot: mixed / SWMR

| Index | 1 workers Mreq/s | 4 workers Mreq/s | 8 workers Mreq/s | 4 workers: readers Mreq/s | 8 workers: readers Mreq/s | 4 workers: writer Mversions/s | 8 workers: writer Mversions/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 1.515 | 3.182 | 4.274 | 3.157 | 4.241 | 1.304 | 1.358 |
| btreeolc | 1.144 | 2.709 | 2.708 | 2.688 | 2.687 | 0.731 | 0.780 |
| unodb_art | 1.136 | 2.559 | 3.735 | 2.539 | 3.706 | 1.220 | 1.129 |
| wormhole | 0.775 | 1.729 | 3.743 | 1.715 | 3.714 | 1.101 | 1.158 |
| cse_crossbeam | 1.014 | 2.040 | 3.917 | 2.024 | 3.887 | 1.297 | 1.216 |

### Lifecycle

| Index | Load s | Freeze phase µs | Freeze sampled call µs | Flush Mversions/s | Destroy s |
| --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 0.006 | 23.994 | 0.119 | 11.980 | 0.000 |
| btreeolc | 0.013 | 24.601 | 0.346 | 9.384 | 0.001 |
| unodb_art | 0.012 | 33.345 | 0.434 | 2.191 | 0.002 |
| wormhole | 0.007 | 25.155 | 0.259 | 7.603 | 0.002 |
| cse_crossbeam | 0.009 | 24.067 | 0.727 | 6.781 | 0.001 |

## pilot: history / history_v64

User keys: 1,000; operation budget: 4,000; repetitions: 1. Profile: `{"batch_size": 32, "delete_percent": 10, "distribution": "uniform", "key_layout": "random", "key_size": 16, "miss_percent": 10, "prefix_bytes": 0, "prefix_groups": 1, "read_percent": 80, "read_view": "historical", "scan_length": 100, "scan_ops": 1024, "scan_percent": 0, "snapshot_lag": 63, "value_size": 32, "versions": 64}`.

### Single-thread operations

| Index | Load Mversions/s | Historical Get Mreq/s | Historical scan Mrows/s | RSS MiB after load | Bytes/version |
| --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 1.908 | 1.629 | 0.177 | 4.898 | 80.256 |
| btreeolc | 1.035 | 1.413 | 0.035 | 12.895 | 211.264 |
| unodb_art | 1.980 | 1.298 | 0.020 | 9.281 | 152.064 |
| wormhole | 2.353 | 0.568 | 0.066 | 16.242 | 266.112 |
| cse_crossbeam | 1.862 | 0.313 | 0.225 | 10.090 | 165.312 |

### Fixed historical snapshot: mixed / SWMR

| Index | 1 workers Mreq/s | 4 workers Mreq/s | 8 workers Mreq/s | 4 workers: readers Mreq/s | 8 workers: readers Mreq/s | 4 workers: writer Mversions/s | 8 workers: writer Mversions/s |
| --- | --- | --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 1.233 | 3.020 | 3.782 | 2.996 | 3.753 | 1.212 | 1.211 |
| btreeolc | 0.860 | 1.869 | 2.038 | 1.854 | 2.022 | 0.568 | 0.577 |
| unodb_art | 1.118 | 2.720 | 3.956 | 2.699 | 3.925 | 1.426 | 1.286 |
| wormhole | 0.290 | 1.164 | 1.426 | 1.155 | 1.415 | 0.300 | 0.382 |
| cse_crossbeam | 0.239 | 0.792 | 1.619 | 0.786 | 1.606 | 1.340 | 1.288 |

### Lifecycle

| Index | Load s | Freeze phase µs | Freeze sampled call µs | Flush Mversions/s | Destroy s |
| --- | --- | --- | --- | --- | --- |
| rocksdb_inlineskiplist | 0.034 | 25.254 | 0.165 | 10.164 | 0.000 |
| btreeolc | 0.063 | 25.275 | 0.300 | 5.717 | 0.002 |
| unodb_art | 0.032 | 24.473 | 0.412 | 2.729 | 0.010 |
| wormhole | 0.027 | 25.344 | 0.320 | 7.269 | 0.005 |
| cse_crossbeam | 0.036 | 33.043 | 0.957 | 4.254 | 0.014 |
