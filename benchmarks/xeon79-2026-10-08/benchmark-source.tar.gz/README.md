# memtable-bench

A C++20 harness for comparing ordered in-memory indexes as LSM MemTable candidates.
The reference `std::map` adapter has no external dependencies. Eight optional
index adapters are implemented with pinned upstream sources. The actual binary's
`--list-indexes` output is authoritative, including CPU restrictions and key limits.

## Status

| Adapter | CMake option suffix | Concurrency in this harness | Complete binary key limit |
| --- | --- | --- | --- |
| `std_map` | Default | Coarse reader/writer lock | Allocation limits |
| `abseil_btree` | `ABSEIL` | Coarse reader/writer lock | Allocation limits |
| `tlx_btree` | `TLX` | Coarse reader/writer lock | Allocation limits |
| `rocksdb_inlineskiplist` | `ROCKSDB` | Native concurrent insert; append-only | uint32 record lengths |
| `btreeolc` | `BTREEOLC` | Native OLC pages + 256 key stripes for exact size/upsert | Allocation limits |
| `unodb_art` | `UNODB` | UnoDB `olc_db`, QSBR; append-only | Encoded key/value lengths fit uint32 |
| `masstree` | `MASSTREE` | Native Masstree locks + deferred node/value reclamation | 1024 bytes |
| `hot` | `HOT` | HOTSingleThreaded + coarse reader/writer lock | 127 bytes |
| `wormhole` | `WORMHOLE` | Native `whsafe` API + parked thread references | 65535 bytes |

Every optional option is named `MEMTABLE_BENCH_FETCH_<SUFFIX>` and defaults to OFF.
These adapters use the actual upstream index; unavailable adapters fail before
creating a result file. HOT requires x86-64 with AVX2, BMI, BMI2, POPCNT and LZCNT.
An ARM64 build explicitly leaves it unavailable. A compiled x86 binary checks CPU
features before entering the HOT translation unit.

**Local validation (2026-10-08):** AppleClang 16, macOS, ARM64/M4: all eight
available adapters (including `std_map`) passed the combined contract and workload
tests. BTreeOLC, UnoDB, Masstree and Wormhole also passed ASan/UBSan tests.
HOT compiled and linked for x86-64 with AppleClang; Rosetta does not expose the
required ISA, so HOT was **not runtime-tested here**. The Linux x86 GCC/Clang CI
workflow includes a required HOT runtime check; this workflow has not been run
remotely as part of this local change.

**Native Linux validation (2026-10-08):** GCC 11.3.1 on Xeon Gold 6240:
all nine adapters, including HOT, passed 10/10 contract/workload tests.
The workload tests also run with node 0 memory binding and pinned physical cores.

All adapters receive identical logical binary keys and values. UnoDB and HOT
store order-preserving terminated nibble keys: `2 * logical_key_bytes + 1` bytes.
CSV records this as `adapter_key_encoding=nibble_terminated`; other adapters use
`binary`. Encoding, decoding and record ownership costs are included in results.
See the integration notes below before comparing memory or concurrent throughput.

## Build

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j 4
ctest --test-dir build --output-on-failure
```

The default build has no downloaded dependencies. Enable all optional adapters
with the proxy-free build script:

```sh
./scripts/build_all.sh build-all -G Ninja
```

On macOS, select system compilers in a **new** build directory if needed:

```sh
./scripts/build_all.sh build-all -G Ninja \
  -DCMAKE_C_COMPILER=/usr/bin/clang -DCMAKE_CXX_COMPILER=/usr/bin/clang++
```

To enable only the five research indexes:

```sh
env -u HTTP_PROXY -u HTTPS_PROXY -u ALL_PROXY \
    -u http_proxy -u https_proxy -u all_proxy \
  cmake -S . -B build-research -DCMAKE_BUILD_TYPE=Release \
  -DMEMTABLE_BENCH_FETCH_BTREEOLC=ON -DMEMTABLE_BENCH_FETCH_UNODB=ON \
  -DMEMTABLE_BENCH_FETCH_MASSTREE=ON -DMEMTABLE_BENCH_FETCH_HOT=ON \
  -DMEMTABLE_BENCH_FETCH_WORMHOLE=ON
cmake --build build-research --target memtable_bench adapter_contract -j 4
ctest --test-dir build-research --output-on-failure
./build-research/memtable_bench --list-indexes
```

The new integrations target 64-bit Linux/macOS with GCC/Clang, on x86-64 or ARM64;
HOT is x86-only. Wormhole uses SSE4.2 on x86 and CRC extensions on ARM64, so the
host must support those instructions. UnoDB's x86 baseline uses SSE4.1, with AVX2
explicitly disabled in this integration. No performance results from Rosetta
should be mixed with native results.

The five new integrations use full commit pins, and configuration verifies the checked-out
commit even with `FETCHCONTENT_SOURCE_DIR_<NAME>` overrides. For the five new
libraries, `cmake/FetchGit.cmake` performs a proxy-free shallow fetch;
`cmake/patches/` contains all changes to upstream code. Reconfiguration is
idempotent and fails if a patch cannot apply to the expected sources.
An installed Boost is used for UnoDB; otherwise pinned Boost 1.86 headers are
fetched with a SHA-256 check. Upstream developer static-analysis tools, tests,
servers and benchmarks are excluded from this embedded build.
RocksDB compiles its support library with tools, tests and optional compression
libraries disabled. Pins and license details are in [THIRD_PARTY.md](THIRD_PARTY.md).

## Run

```sh
./build/memtable_bench --stage all --index std_map \
  --keys 100000 --ops 1000000 --key-size 16 --value-size 64 \
  --distribution uniform --threads 8 --read-percent 80 \
  --scan-length 100 --output results.csv

./build/memtable_bench --stage 3 --index std_map --internal-key \
  --keys 100000 --key-size 24 --value-size 128 \
  --distribution zipf --output lifecycle.csv

./build-rocksdb/memtable_bench --stage all --index rocksdb_inlineskiplist \
  --internal-key --keys 100000 --ops 1000000 --threads 8 \
  --key-size 24 --value-size 64 --output rocksdb.csv
```

For the newly integrated native concurrent indexes, use a common append-only
MVCC workload (one result file per index):

```sh
for index in btreeolc unodb_art masstree wormhole; do
  ./build-research/memtable_bench --stage all --index "$index" --internal-key \
    --keys 100000 --ops 1000000 --threads 8 --key-size 24 --value-size 64 \
    --scan-length 100 --distribution uniform --output "$index.csv"
done
# On a supported native x86 machine, the same command accepts --index hot.
```

On Linux, pin worker threads and bind their future allocations to a NUMA node:

```sh
./build/memtable_bench --stage 2 --threads 4 --cpu-list 0,2,4,6 \
  --numa-node 0 --index std_map --output numa.csv
```

CPU IDs must belong to the process's allowed CPU set. The NUMA option uses Linux
`set_mempolicy(MPOL_BIND)` per thread and fails if the requested binding is not
permitted. On macOS these options are rejected explicitly. For a full process
memory/CPU policy, launch through `numactl` as well. Build commands should be run
with proxy environment variables unset on hosts where that is required.

### Reproducible Linux matrix

The standard-library-only runner requires all nine adapters and `numactl`.
It verifies that the chosen CPUs are allowed, belong to the selected NUMA node,
and contain no SMT siblings. Select CPU IDs from your own machine's topology.
This example uses 16 physical cores on node 0 of the Xeon test server:

```sh
python3 scripts/benchmark_matrix.py --binary build-linux/memtable_bench \
  --output results/new-run --cpus 2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17 \
  --numa-node 0 --keys 1000000 --ops 1000000 --repeats 5 --threads 1,2,4,8,16
python3 scripts/summarize_benchmark.py results/new-run
```

The output directory must be new. Runs are serial in randomized interleaved
order, each in a fresh process. Nine excluded warmups precede 360 formal runs:
uniform/Zipf single-thread, uniform lifecycle, and uniform 80/20 mixed workloads
at five thread counts. Each scenario uses identical seeds across adapters;
operation counts, returned row counts and checksums must agree.
`metadata.json` records CPU topology, affinity, NUMA policy, background load,
compiler, dependency pins and binary hash. `raw.csv` adds scenario/repeat/seed/
run_sequence/process_elapsed_s to the harness schema. The summarizer validates
completeness and produces `summary.csv` (median/Q1/Q3/min/max/sample count) and
`report.md`. Retain per-process `runs/` logs and `commands.jsonl` with the report.
Frequency is not locked, and CPUs are not reserved against unrelated processes.

To exercise NUMA binding during the Linux harness integration test:

```sh
MEMTABLE_BENCH_REQUIRE_HOT=1 MEMTABLE_BENCH_TEST_NUMA_NODE=0 \
  MEMTABLE_BENCH_TEST_CPUS=2,3,4,5 ctest --test-dir build-linux --output-on-failure
```

## Three stages and measurement rules

1. **Single thread:** construct an index, insert each user key once, run exact-key
   gets, freeze outside the timed region, then run bounded ordered scans. Insert order is a seeded permutation for
   `uniform`/`zipf`, sequential for `sequential`. The selected distribution controls
   read and scan start IDs. Zipf uses exponent 1.1. `scan_length` is a maximum
   per scan.
2. **Concurrent scaling:** prefill an index, then run a seeded trace of `ops`
   mixed exact-key reads and inserts/updates across `threads` workers. Reads target
   prefilled versions so all reads are hits. Without `--internal-key`, writes update
   existing keys. With it, writes insert unique newer versions. The start barrier
   excludes thread creation; throughput uses the wall time until all workers finish.
   RocksDB and UnoDB are append-only: stage 2 writes require `--internal-key`. Without it, a
   read-only phase (`--read-percent 100`) is allowed. Incompatible workloads are
   rejected before creating output. Duplicate exact keys return false for these two adapters; the other adapters
   implement upsert.
3. **MemTable lifecycle:** create, insert, `Freeze`, one complete ordered scan
   simulating a flush, then destroy the index. The flush verifies strict key order
   and exact row count. Freeze and destroy get separate timing rows.

The interface is `Insert`, `Get`, `NewCursor` (`Seek`, `Next`), `Scan`, and `Freeze`.
All keys and values are binary strings. `key_size` is the **user key** size (minimum
8 bytes). The first eight bytes are a big-endian user ID; a deterministic suffix
fills larger keys. `--internal-key` appends the one's complement of a big-endian
64-bit sequence and a one-byte value type. This sorts versions of the same user key
newest first. `Get` is an exact **encoded key** lookup; snapshot-visible lookup,
tombstone resolution, and compaction are not implemented.

Frozen std/Abseil/TLX cursors hold a native const iterator: `Seek` calls `lower_bound`
once, and each `Next` increments the iterator without a key/value copy or another
lookup. Full traversal is linear. Cursors created before Freeze retain their safe
active-table behavior, which re-seeks on `Next` to tolerate iterator invalidation
from writes. Stage 1 scan and stage 3 flush always create cursors after Freeze.
RocksDB cursors use its native iterator in both modes and return views into arena
records. The research adapters also traverse their native structures after Freeze, as
detailed below. An index must outlive every cursor.

The [RocksDB InlineSkipList](https://github.com/facebook/rocksdb/blob/v9.10.0/memtable/inlineskiplist.h)
adapter stores `[varint32 key length][key][varint32 value length][value]`
in `InlineSkipList::AllocateKey` storage owned by `ConcurrentArena` (64 KiB blocks,
huge pages disabled). A custom binary comparator preserves the harness's encoded
key order; this is an InternalKey-style benchmark format, not RocksDB's on-disk
InternalKey trailer format. It calls upstream `InsertConcurrently`, with no global
adapter lock. A small atomic admission/count gate lets Freeze stop new writes and
wait for admitted inserts to finish. Its overhead is included in insertion timing.
Published records remain immutable; duplicate attempts retain their unlinked arena
allocation until Destroy. `--seed` controls workload traces; upstream skiplist
height randomness is seeded by its own thread-local generator.

Workload plans and constant values are prepared outside timed regions. Timed
operations include key encoding, adapter locks, value copies, cursor work, and
one-in-64 latency sampling. The checksum prevents the scans and reads from being
discarded. Stage 1 and 3 report index growth against a pre-construction RSS sample.
Stage 2 samples RSS after prefill and trace preparation, so its RSS delta is
*additional memory during the mixed phase*, including worker stacks and runtime
allocations. RSS is process-wide and page-granular;
allocator retention can make the destroy delta smaller than the index allocation.
Run one benchmark process at a time and repeat experiments for stable comparisons.

## CSV schema

Each row is one phase. The file is appended if it exists; a new file gets the
header described below. Existing files with a different header are rejected
without appending. Use a new output file when moving from the previous 35-column
schema to this 36-column schema.

| Columns | Meaning |
| --- | --- |
| `run_id,index,adapter_mode,stage,phase` | Run epoch nanoseconds, adapter and phase |
| `threads,keys,ops,items_scanned` | Workload counts; `ops` is scan calls for stage 1 and 3 |
| `key_size,value_size,internal_key,distribution,read_percent,scan_length` | Workload parameters |
| `cpu_list,numa_node` | Requested placement; empty when absent |
| `elapsed_ns,throughput_ops_s,items_per_s` | Wall time and rates |
| `latency_p50_ns,latency_p95_ns,latency_p99_ns` | Sampled operation latency, one in 64; one sample for single-operation phases |
| `cycles_per_op,instructions_per_op,ipc` | Linux thread-local perf counters, aggregated across workers in stage 2 |
| `l1d_miss_per_op,llc_miss_per_op,branch_miss_per_op,dtlb_miss_per_op` | Linux hardware/cache misses per operation |
| `rss_before_bytes,rss_after_bytes,rss_delta_bytes,bytes_per_key` | Resident memory; bytes/key is RSS delta divided by current index count (or pre-destroy count) |
| `checksum` | Accumulated digest of observed data |
| `adapter_key_encoding` | `binary` or `nibble_terminated`; final column, schema v2 has 36 fields |

On macOS, and on Linux when `perf_event_open` is unavailable or restricted,
hardware counter fields are **empty**, never zero-filled. Linux counts exclude
kernel/hypervisor execution and are scaled by enabled/running time when multiplexed.
The counters are thread-local. A stage 2 metric is blank if any worker lacks it.
For `ordered_flush`, `items_per_s` is the useful throughput; `ops` is one scan.

## Research adapter integration notes

- **BTreeOLC:** upstream nodes require trivially copyable keys, so the adapter
  stores one-word pointers to binary views over immutable owned records. Its upstream `scan` stops at
  one leaf; active cursors perform an optimistic path traversal, while frozen
  cursors increment through native leaf arrays using a parent stack. Individual
  records, including overwritten values, stay alive until Destroy. Equal keys are
  serialized by a 256-stripe mutex array because upstream `insert` returns no
  created/upsert result. The extra lookup, stripes and record allocations are
  timed. The patch fixes empty-node `lowerBound`, uninitialized lookup misses,
  missing headers and ARM pause instructions. The upstream OLC page fields use
  plain reads under version validation; ASan/UBSan success is not a proof of
  C++ data-race freedom. TSan cleanliness is not claimed.
- **UnoDB ART:** uses `olc_db<key_view,value_view>` and QSBR. Terminated nibble
  encoding removes embedded zero bytes and makes keys prefix-free. The thread
  registration patch exposes an idempotent registration method for the harness's
  ordinary `std::thread` workers; upstream TLS destruction unregisters them.
  Every operation/movement announces quiescence. An idle registered thread can
  delay QSBR reclamation until it resumes or exits; the memory measurement includes
  this behavior. Live cursors use public `scan_from`, copy one record, and re-seek
  for the next movement. Frozen cursors use the pinned internal
  `test_only_iterator()` API for native linear traversal, decoding each key.
  This internal API makes the commit pin part of the adapter's compatibility
  contract. No update/remove operation is exposed.
- **Masstree:** uses `basic_table` with owned immutable record pointers and a
  custom per-index allocation context. Retired suffix/node memory and overwritten
  records are deferred until Destroy, avoiding the upstream server's global RCU
  thread lists and allocator pools. Live cursors use native range-scan callbacks;
  frozen cursors traverse leaf permutations, sibling links and trie layers.
  The ARM patch supplies atomic exchange, memory fences, pause/prefetch and
  byte-swap operations. ARM fences are conservative and their overhead is part
  of results. A separate permutation patch handles the empty remainder of a
  full 64-bit permutation without shifting by 64. With `--internal-key`, maximum
  user key size is 1015 bytes.
- **HOT:** uses the upstream `HOTSingleThreaded` trie, C-string key extraction
  over terminated nibble keys, owned original keys/values and a reader/writer
  lock. The upstream process-wide node pool can retain memory after Destroy;
  run one HOT index at a time per process. This measures wrapper scalability; **native HOTRowex concurrency is not
  integrated**. Frozen cursors use its native iterator. Upstream's 255-byte key
  buffer gives a 127-byte complete logical binary key limit, or a 118-byte user
  key with `--internal-key`. Clang patches fix restrict/alignment declarations,
  template definition ordering/specializations and replace an equivalent MMX
  byte-mask operation with SSE2. ISA flags apply only to the HOT source file.
  TODO: run the contract/workload tests on native x86 hardware and add a separate
  ROWEX adapter if native HOT concurrency is needed.
- **Wormhole:** uses native `whsafe_get`/`whsafe_merge`, with one parked reference
  per participating thread, owned by the index. The native merge callback under
  the leaf lock gives accurate size accounting for concurrent upserts. Active
  cursors copy a record and park after each movement so a retained cursor cannot
  deadlock a write in the same thread. Frozen cursors use native `whunsafe`
  iteration after admitted writes drain. The assembly patch uses newline-separated
  instructions and portable 16-byte alignment for the coroutine helper symbols
  on Apple's ARM assembler. Complete keys are capped at 65535 bytes; values must
  fit uint32. The default memory manager duplicates accepted key/value records.

None of these adapters constructs a separate sorted container for flush scans.
All four native concurrent research adapters include the admission/drain gate in
Insert/Freeze timing. Upsert adapters can retain old records to protect cursors;
append-only InternalKey workloads are the most representative common comparison.

## Verification

`adapter_contract` verifies empty/binary/prefix keys, misses, MVCC ordering, seek
across gaps and leaves, full scans, duplicate/upsert policy, concurrent readers,
writers, scans and Freeze, key limits, and active cursors retained across writes.
The BTreeOLC case forces a tree with multiple inner levels. CTest also exercises
all three workload stages for enabled adapters. If Python 3 is available,
`harness_integration` compares checksums and row counts against `std_map`, validates
36-column CSV metadata and checks rejection before output creation. Unavailable
indexes are tested as unavailable; `MEMTABLE_BENCH_REQUIRE_HOT=1` makes missing HOT
CPU support a test failure, as used by the Linux x86 CI job.

For ASan/UBSan, use a separate Debug build and pass both compiler flags:

```sh
./scripts/build_all.sh build-sanitize -G Ninja -DCMAKE_BUILD_TYPE=Debug \
  '-DCMAKE_C_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer' \
  '-DCMAKE_CXX_FLAGS=-fsanitize=address,undefined -fno-omit-frame-pointer'
```

Set `UBSAN_OPTIONS=halt_on_error=1 ASAN_OPTIONS=halt_on_error=1` when running tests.
Sanitized builds are correctness checks and should not be used for rankings.

## Layout

```text
CMakeLists.txt                 Build options, targets, CTest
include/memtable_bench/index.h Unified ordered-index interface and metadata
src/index.cc                   std/Abseil/TLX adapters, registry, InternalKey encoding
src/main.cc                    Workloads, placement, metrics, CSV
src/adapter_common.h           Write admission, immutable records, nibble codec
src/*_index.cc                 RocksDB and five research adapters
cmake/*.cmake                  Pinned downloads and embedded upstream builds
cmake/patches/                 Reproducible upstream fixes and platform patches
scripts/build_all.sh            Proxy-free all-adapter build/test entry point
tests/adapter_contract.cc       Binary/MVCC/cursor/concurrency/freeze contracts
tests/harness_integration.py    Workload checksum, CSV and rejection checks
.github/workflows/adapters.yml Native x86 GCC/Clang validation (requires HOT ISA)
THIRD_PARTY.md                  Pins, licenses and redistribution considerations
```
