#!/usr/bin/env python3
"""Check equivalent workloads, CSV metadata and early rejection in actual binaries."""
import csv
import os
from pathlib import Path
import subprocess
import sys
import tempfile

binary = str(Path(sys.argv[1]).resolve())
placement = []
if "MEMTABLE_BENCH_TEST_NUMA_NODE" in os.environ:
    placement = ["--numa-node", os.environ["MEMTABLE_BENCH_TEST_NUMA_NODE"],
                 "--cpu-list", os.environ["MEMTABLE_BENCH_TEST_CPUS"]]

def invoke(*args, succeeds=True):
    result = subprocess.run([binary, *placement, *map(str, args)], text=True, capture_output=True, timeout=90)
    if (result.returncode == 0) != succeeds:
        raise AssertionError(f"{args}: exit {result.returncode}\n{result.stdout}\n{result.stderr}")
    return result.stdout

adapters = {}
for line in invoke("--list-indexes").splitlines():
    fields = line.split("\t")
    metadata = dict(field.split("=", 1) for field in fields[3:])
    adapters[fields[0]] = (fields[1] == "available", metadata)
if os.environ.get("MEMTABLE_BENCH_REQUIRE_HOT") == "1" and not adapters["hot"][0]:
    raise AssertionError("HOT runtime validation requires a CPU with its advertised ISA features")

with tempfile.TemporaryDirectory(prefix="memtable-contract-") as directory:
    root = Path(directory)
    reference = None
    for name, (available, metadata) in adapters.items():
        output = root / (name + ".csv")
        if not available:
            invoke("--index", name, "--output", output, succeeds=False)
            assert not output.exists(), name
            continue
        invoke("--stage", "all", "--index", name, "--internal-key", "--keys", 2500,
               "--ops", 5000, "--threads", 4, "--key-size", 24, "--value-size", 64,
               "--scan-length", 37, "--distribution", "zipf", "--output", output)
        with output.open(newline="") as stream:
            reader = csv.DictReader(stream)
            assert len(reader.fieldnames) == 36, reader.fieldnames
            rows = list(reader)
        assert len(rows) == 8, name
        observed = []
        for row in rows:
            assert None not in row and None not in row.values(), row
            assert row["index"] == name and row["adapter_mode"], row
            assert row["adapter_key_encoding"] == metadata["key_encoding"], row
            assert row["key_size"] == "24" and row["internal_key"] == "1", row
            assert float(row["throughput_ops_s"]) > 0, row
            observed.append(tuple(row[field] for field in
                                  ("stage", "phase", "ops", "items_scanned", "checksum")))
        if reference is None:
            reference = observed
        assert observed == reference, f"workload/checksum mismatch: {name}"
        print(f"{name}: all stages, CSV and checksums match std_map")

        if name in ("unodb_art", "rocksdb_inlineskiplist"):
            rejected = root / (name + "-upsert.csv")
            invoke("--stage", 2, "--index", name, "--read-percent", 0,
                   "--output", rejected, succeeds=False)
            assert not rejected.exists(), name
        if "max_key_bytes" in metadata:
            rejected = root / (name + "-too-long.csv")
            invoke("--stage", 3, "--index", name, "--internal-key",
                   "--key-size", metadata["max_key_bytes"], "--output", rejected, succeeds=False)
            assert not rejected.exists(), name

    old_schema = root / "old-schema.csv"
    old_schema.write_text("index,checksum\nstd_map,1\n")
    invoke("--stage", 3, "--keys", 10, "--output", old_schema, succeeds=False)
    assert old_schema.read_text() == "index,checksum\nstd_map,1\n"
